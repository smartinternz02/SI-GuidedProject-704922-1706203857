
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String



def static "com.qa.test.customFunctions.CheckDropDownlistElementExist"(
    	TestObject object	
     , 	String option	) {
    (new com.qa.test.customFunctions()).CheckDropDownlistElementExist(
        	object
         , 	option)
}
