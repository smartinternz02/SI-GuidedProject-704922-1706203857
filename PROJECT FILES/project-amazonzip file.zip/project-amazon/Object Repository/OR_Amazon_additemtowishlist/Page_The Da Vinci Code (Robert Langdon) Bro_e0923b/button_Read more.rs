<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Read more</name>
   <tag></tag>
   <elementGuidId>b070148d-79c7-455c-9da2-b36bb70069f2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button[name=&quot;read-more&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@name='read-more']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>3bfa7997-328c-475f-83ce-17086979e4fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>readInteractable</value>
      <webElementGuid>b9f49990-269d-4e4a-9110-c15a2afc3bc1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>read-more</value>
      <webElementGuid>3c769ece-5e23-4b28-b834-952bf54e3b64</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 
                                            
                                            
                                            Read more
                                        </value>
      <webElementGuid>4f274069-3bf6-4353-8b64-93fc7e4ca1f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;productInfoTabExpander0&quot;)/div[@class=&quot;pInfoTabCExpander-interactable-container&quot;]/span[@class=&quot;pInfoTabCExpander-label-expand&quot;]/button[@class=&quot;readInteractable&quot;]</value>
      <webElementGuid>4a256be5-2b3c-4e8a-9e05-c9838c4c2521</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@name='read-more']</value>
      <webElementGuid>ea22ed82-5b5f-4e60-8ade-ccd401b91637</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='productInfoTabExpander0']/div[3]/span/button</value>
      <webElementGuid>c16a9c80-784c-4e37-a62c-8b0a274d45b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/span/button</value>
      <webElementGuid>279f0457-22e8-45b3-9099-925c5e7b2f14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@name = 'read-more' and (text() = ' 
                                            
                                            
                                            Read more
                                        ' or . = ' 
                                            
                                            
                                            Read more
                                        ')]</value>
      <webElementGuid>5a8e2519-948f-4aa5-adc9-15c60c574a47</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
