<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_All Departments        Arts  Crafts _135c92</name>
   <tag></tag>
   <elementGuidId>7554228a-ddc8-484c-bb0a-00001cff589c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>01a6a25f-2522-4507-99d8-8ab0d4450d2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>a254a0c8-5d21-4da0-90e3-4cafcf5e1daa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>7ec2f3dd-656c-4df5-ab17-e41adebf7001</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>k+fyIAyB82R9jVEmroQ0OWwSW3A=</value>
      <webElementGuid>af995ff7-2669-4b0f-b122-d4a15923b4ed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>5</value>
      <webElementGuid>fa5bb49d-5ced-4310-a249-8bc6b5eac81b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>b9279e9b-06bc-415c-a64f-7a6743121110</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>dcdb5d44-8d1a-4300-8cec-24e4f35b9b72</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>a65b36d6-dd2d-42a3-a600-4999db0b29f2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>208f923b-e1ca-4656-b5c6-fccd4f6ba9d0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys' Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls' Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men's Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women's Fashion
    </value>
      <webElementGuid>98125c68-6a3e-4ed4-98b6-5cfec72da37b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>45354e55-1513-44f7-aebd-3614ec5bd79e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>2dbddbfa-c14e-466c-8a62-857744c00a0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>92dc637e-571a-46bc-a794-3edf5e670673</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>7e9fdf3e-f67f-4e60-89f8-169939765dd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = concat(&quot;
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys&quot; , &quot;'&quot; , &quot; Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls&quot; , &quot;'&quot; , &quot; Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men&quot; , &quot;'&quot; , &quot;s Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women&quot; , &quot;'&quot; , &quot;s Fashion
    &quot;) or . = concat(&quot;
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys&quot; , &quot;'&quot; , &quot; Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls&quot; , &quot;'&quot; , &quot; Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men&quot; , &quot;'&quot; , &quot;s Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women&quot; , &quot;'&quot; , &quot;s Fashion
    &quot;))]</value>
      <webElementGuid>3c617fc2-401c-4178-8525-63a7b87615b2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
