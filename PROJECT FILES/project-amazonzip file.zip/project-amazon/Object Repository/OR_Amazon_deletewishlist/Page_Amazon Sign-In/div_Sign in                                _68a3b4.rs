<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Sign in                                _68a3b4</name>
   <tag></tag>
   <elementGuidId>5683ce4f-8e14-4472-bd34-b31a469c175a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-box-inner.a-padding-extra-large</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>#</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>dfb6d96e-ffdd-4b54-9f71-d8016262554f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-box-inner a-padding-extra-large</value>
      <webElementGuid>8b68f1b4-efe1-49e2-99c8-d345cc684553</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
          
            Sign in
          
          
          
          
            
              Email or mobile phone number
            
            
            
              
                
              
              
            
            

            
            
            




  Enter your email or mobile phone number


          

          
          

          
            
            









            
            
              Continue
            

            
            
              




  By continuing, you agree to Amazon's Conditions of Use and Privacy Notice.
 

            

            

  function cf() {
    if (typeof window.uet === 'function') {
      uet('cf');
    }
    if (window.embedNotification &amp;&amp;
      typeof window.embedNotification.onCF === 'function') {
      embedNotification.onCF();
    }
  }


cf()

          

          

          

          




  
    
      Need help?
    
    
      
        



  
  
    
  


  Forgot your password?

      
    
    
      
        Other issues with Sign-In
      
    
  



          




  
  
  
    
      
      
      
        
        
      
    
  


          
          

          






          
            




    
    
        
            Buying for work?
        
    

    
        
            Shop on Amazon Business
        
    

          
        </value>
      <webElementGuid>ce948cc6-7908-45cb-a0fe-1387b4f45b55</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;authportal-main-section&quot;)/div[@class=&quot;a-section auth-pagelet-container&quot;]/div[@class=&quot;a-section a-spacing-base&quot;]/div[@class=&quot;a-section&quot;]/form[@class=&quot;auth-validate-form auth-real-time-validation a-spacing-none&quot;]/div[@class=&quot;a-section&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]</value>
      <webElementGuid>c680dff8-eab2-4e89-8933-e8d4de35344d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='authportal-main-section']/div[2]/div[2]/div/form/div/div/div</value>
      <webElementGuid>510b92b6-3169-4f0f-b7f4-663427bd96eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div/div/div</value>
      <webElementGuid>84ef9816-9696-4261-ade7-74aad840d47c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;
          
            Sign in
          
          
          
          
            
              Email or mobile phone number
            
            
            
              
                
              
              
            
            

            
            
            




  Enter your email or mobile phone number


          

          
          

          
            
            









            
            
              Continue
            

            
            
              




  By continuing, you agree to Amazon&quot; , &quot;'&quot; , &quot;s Conditions of Use and Privacy Notice.
 

            

            

  function cf() {
    if (typeof window.uet === &quot; , &quot;'&quot; , &quot;function&quot; , &quot;'&quot; , &quot;) {
      uet(&quot; , &quot;'&quot; , &quot;cf&quot; , &quot;'&quot; , &quot;);
    }
    if (window.embedNotification &amp;&amp;
      typeof window.embedNotification.onCF === &quot; , &quot;'&quot; , &quot;function&quot; , &quot;'&quot; , &quot;) {
      embedNotification.onCF();
    }
  }


cf()

          

          

          

          




  
    
      Need help?
    
    
      
        



  
  
    
  


  Forgot your password?

      
    
    
      
        Other issues with Sign-In
      
    
  



          




  
  
  
    
      
      
      
        
        
      
    
  


          
          

          






          
            




    
    
        
            Buying for work?
        
    

    
        
            Shop on Amazon Business
        
    

          
        &quot;) or . = concat(&quot;
          
            Sign in
          
          
          
          
            
              Email or mobile phone number
            
            
            
              
                
              
              
            
            

            
            
            




  Enter your email or mobile phone number


          

          
          

          
            
            









            
            
              Continue
            

            
            
              




  By continuing, you agree to Amazon&quot; , &quot;'&quot; , &quot;s Conditions of Use and Privacy Notice.
 

            

            

  function cf() {
    if (typeof window.uet === &quot; , &quot;'&quot; , &quot;function&quot; , &quot;'&quot; , &quot;) {
      uet(&quot; , &quot;'&quot; , &quot;cf&quot; , &quot;'&quot; , &quot;);
    }
    if (window.embedNotification &amp;&amp;
      typeof window.embedNotification.onCF === &quot; , &quot;'&quot; , &quot;function&quot; , &quot;'&quot; , &quot;) {
      embedNotification.onCF();
    }
  }


cf()

          

          

          

          




  
    
      Need help?
    
    
      
        



  
  
    
  


  Forgot your password?

      
    
    
      
        Other issues with Sign-In
      
    
  



          




  
  
  
    
      
      
      
        
        
      
    
  


          
          

          






          
            




    
    
        
            Buying for work?
        
    

    
        
            Shop on Amazon Business
        
    

          
        &quot;))]</value>
      <webElementGuid>d5a5cabf-babf-4d90-8420-57881997f26e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
