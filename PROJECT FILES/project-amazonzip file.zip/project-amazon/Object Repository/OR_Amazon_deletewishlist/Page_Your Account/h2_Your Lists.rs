<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Your Lists</name>
   <tag></tag>
   <elementGuidId>81a1f195-01d1-4f06-b764-03e686b255e5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div/div[5]/div/a/div/div/div/div[2]/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>3b9874d8-cac3-4758-ad77-0711edb71cfa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-none ya-card__heading--rich a-text-normal</value>
      <webElementGuid>ee2f26b6-be51-4186-8cd2-f81e80301f63</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Your Lists
                </value>
      <webElementGuid>d08df160-e3a1-464c-bdad-407907a49327</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-section ya-personalized&quot;]/div[@class=&quot;ya-card-row&quot;]/div[@class=&quot;ya-card-cell&quot;]/a[@class=&quot;ya-card__whole-card-link&quot;]/div[@class=&quot;a-box ya-card--rich&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span9 a-span-last&quot;]/h2[@class=&quot;a-spacing-none ya-card__heading--rich a-text-normal&quot;]</value>
      <webElementGuid>7c27dc96-5ffe-4e0a-82e9-7781e90daa4f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div/div[5]/div/a/div/div/div/div[2]/h2</value>
      <webElementGuid>98b90519-3860-4bac-a057-af4325dfee80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/a/div/div/div/div[2]/h2</value>
      <webElementGuid>54d88729-39fc-45d4-9c3b-92dbdc11c9e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
                    Your Lists
                ' or . = '
                    Your Lists
                ')]</value>
      <webElementGuid>181061b2-6c3e-44d3-b857-c0375df8caf5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
