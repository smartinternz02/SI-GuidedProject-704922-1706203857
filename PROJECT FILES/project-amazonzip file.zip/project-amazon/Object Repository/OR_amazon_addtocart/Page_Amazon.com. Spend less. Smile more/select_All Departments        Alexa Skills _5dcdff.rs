<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_All Departments        Alexa Skills _5dcdff</name>
   <tag></tag>
   <elementGuidId>5ab203fe-db62-4f50-b649-cec0c5cbbc50</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>4e65803b-ebe1-413b-8a36-fd7df4db0139</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>43c3bee5-e22f-4f82-b1fe-ce25673e733a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>71f30b8d-cfef-42ed-a335-3b3ce63b45f1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>3DfYDRQEn+aN/cwy9HNDCjsQFog=</value>
      <webElementGuid>a34646f7-ec41-460f-a812-e70e583acf57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>77cc725c-1a98-4a1a-aa91-d08c20c62f74</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>95fed931-1ad1-4d85-b6c3-65ac2d3c6088</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>a3a41721-ac8b-40df-a99a-7628dcabb294</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>048ff13c-e2a3-4c0e-9c86-f71af9b05d99</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>75d35b40-e78d-49f7-8cb5-98fdfbeadff3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Departments
        Alexa Skills
        Amazon Clinic
        Amazon Devices
        Amazon Fresh
        Amazon Pharmacy
        Amazon Warehouse
        Appliances
        Apps &amp; Games
        Arts, Crafts &amp; Sewing
        Audible Books &amp; Originals
        Automotive Parts &amp; Accessories
        Baby
        Beauty &amp; Personal Care
        Books
        CDs &amp; Vinyl
        Cell Phones &amp; Accessories
        Clothing, Shoes &amp; Jewelry
           Women
           Men
           Girls
           Boys
           Baby
        Collectibles &amp; Fine Art
        Computers
        Credit and Payment Cards
        Digital Music
        Electronics
        Garden &amp; Outdoor
        Gift Cards
        Grocery &amp; Gourmet Food
        Handmade
        Health, Household &amp; Baby Care
        Home &amp; Business Services
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Just for Prime
        Kindle Store
        Luggage &amp; Travel Gear
        Luxury Stores
        Magazine Subscriptions
        Movies &amp; TV
        Musical Instruments
        Office Products
        Pet Supplies
        Premium Beauty
        Prime Video
        Smart Home
        Software
        Sports &amp; Outdoors
        Subscribe &amp; Save
        Subscription Boxes
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under $10
        Video Games
        Whole Foods Market
    </value>
      <webElementGuid>a6107790-96fe-47d4-bae0-c167db646c0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>c9395bcc-29fb-4626-ab2b-7e80e1e4087f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>e4c8a10d-d405-49d3-9b76-48010db48cc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>c07bbec4-90e4-4790-b20c-d0b42bfea6fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>996996cd-3857-492b-a773-0200f9a22a6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = '
        All Departments
        Alexa Skills
        Amazon Clinic
        Amazon Devices
        Amazon Fresh
        Amazon Pharmacy
        Amazon Warehouse
        Appliances
        Apps &amp; Games
        Arts, Crafts &amp; Sewing
        Audible Books &amp; Originals
        Automotive Parts &amp; Accessories
        Baby
        Beauty &amp; Personal Care
        Books
        CDs &amp; Vinyl
        Cell Phones &amp; Accessories
        Clothing, Shoes &amp; Jewelry
           Women
           Men
           Girls
           Boys
           Baby
        Collectibles &amp; Fine Art
        Computers
        Credit and Payment Cards
        Digital Music
        Electronics
        Garden &amp; Outdoor
        Gift Cards
        Grocery &amp; Gourmet Food
        Handmade
        Health, Household &amp; Baby Care
        Home &amp; Business Services
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Just for Prime
        Kindle Store
        Luggage &amp; Travel Gear
        Luxury Stores
        Magazine Subscriptions
        Movies &amp; TV
        Musical Instruments
        Office Products
        Pet Supplies
        Premium Beauty
        Prime Video
        Smart Home
        Software
        Sports &amp; Outdoors
        Subscribe &amp; Save
        Subscription Boxes
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under $10
        Video Games
        Whole Foods Market
    ' or . = '
        All Departments
        Alexa Skills
        Amazon Clinic
        Amazon Devices
        Amazon Fresh
        Amazon Pharmacy
        Amazon Warehouse
        Appliances
        Apps &amp; Games
        Arts, Crafts &amp; Sewing
        Audible Books &amp; Originals
        Automotive Parts &amp; Accessories
        Baby
        Beauty &amp; Personal Care
        Books
        CDs &amp; Vinyl
        Cell Phones &amp; Accessories
        Clothing, Shoes &amp; Jewelry
           Women
           Men
           Girls
           Boys
           Baby
        Collectibles &amp; Fine Art
        Computers
        Credit and Payment Cards
        Digital Music
        Electronics
        Garden &amp; Outdoor
        Gift Cards
        Grocery &amp; Gourmet Food
        Handmade
        Health, Household &amp; Baby Care
        Home &amp; Business Services
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Just for Prime
        Kindle Store
        Luggage &amp; Travel Gear
        Luxury Stores
        Magazine Subscriptions
        Movies &amp; TV
        Musical Instruments
        Office Products
        Pet Supplies
        Premium Beauty
        Prime Video
        Smart Home
        Software
        Sports &amp; Outdoors
        Subscribe &amp; Save
        Subscription Boxes
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under $10
        Video Games
        Whole Foods Market
    ')]</value>
      <webElementGuid>3ebafe11-c449-475e-ad41-65d9536b9b5d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
