import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.click(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon.com. Spend less. Smile more/a_All'))

WebUI.click(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon.com. Spend less. Smile more/a_Sign in'))

WebUI.setText(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon Sign-In/input_email'), 'p.dheekshithadheekshitha87@gmail.com')

WebUI.click(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon Sign-In/inputcontinue'))

WebUI.setEncryptedText(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon Sign-In/input_password'), 
    'NNtPoxDRXerj230kligMUA==')

WebUI.click(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon Sign-In/inputsignInSubmit'))

WebUI.setText(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon.com  hp/input_field-keywords'), 
    'masks')

WebUI.click(findTestObject('Amazon_Category_validation_excel_OR/Page_Amazon.com. Spend less. Smile more/input_Search Amazon_nav-search-submit-button'))

WebUI.click(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon.com  masks/h2_NNPCBT 100PCS 3 Ply Black Disposable Fac_341808'))

WebUI.click(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon.com  masks/span_NNPCBT 100PCS 3 Ply Black Disposable F_643930'))

WebUI.click(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon.com  NNPCBT 100PCS 3 Ply Black _64d849/input_submit.add-to-registry.wishlist'))

WebUI.click(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon.com  NNPCBT 100PCS 3 Ply Black _64d849/input_list-name'))

WebUI.setText(findTestObject('Object Repository/OR_Amazon_additemtowishlist/Page_Amazon.com  NNPCBT 100PCS 3 Ply Black _64d849/input_list-name'), 
    'mask')

WebUI.click(findTestObject('OR_Amazon_additemtowishlist/additions/Page_Amazon.comlist/input_Learn more_a-button-input a-declarative'))

WebUI.click(findTestObject('OR_Amazon_additemtowishlist/additions/Page_Amazon.comlist/a_View List'))

WebUI.verifyTextPresent('NNPCBT 100PCS 3 Ply Black Disposable Face Mask Filter Protection Face Masks', false)

