<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon Checkpoint testsuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>1a5ddc27-f1ae-48e8-bb30-335aaea73c03</testSuiteGuid>
   <testCaseLink>
      <guid>a32fcf17-5baa-4e98-b425-d1b4dc36923b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon/Checkpoint/TC_Validation Amazon Category Checkpoint_001</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>5fd426c5-f9f4-4cb3-9db1-5659044db876</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_Category_Validation_Excel_Data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>5fd426c5-f9f4-4cb3-9db1-5659044db876</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>category</value>
         <variableId>ef698976-5498-4ae4-be91-74c4d140b2c5</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>5fd426c5-f9f4-4cb3-9db1-5659044db876</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>item</value>
         <variableId>8267dc8f-60ca-4c79-9fca-20fdb7567335</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
